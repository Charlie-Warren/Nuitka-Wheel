def speak() -> None:
    """This function prints Hello!"""
    print("Hello!")