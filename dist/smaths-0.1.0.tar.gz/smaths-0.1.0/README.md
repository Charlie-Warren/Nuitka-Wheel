# nuitka-wheel
As of 11 November 2023 [Nuitka](https://github.com/Nuitka/Nuitka) doesn't produce useful pyi files to allow proper typehints and docstrings in their packages.
This project builds a simple maths project into a wheel, compiling it using Nuitka.

Stubgen (from MyPy) is used to generate proper pyi files for the project. In 
[pyproject.toml](pyproject.toml), Nuitka's own pyi generation is disabled,
and instead stubgen's pyi files are added as package data.
