# nuitka-wheel
Trying to build a nuitka wheel that has a correct pyi file.
